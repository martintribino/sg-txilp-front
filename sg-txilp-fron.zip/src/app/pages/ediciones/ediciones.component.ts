import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ediciones',
  templateUrl: './ediciones.component.html',
  styleUrls: ['./ediciones.component.styl']
})
export class EdicionesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
