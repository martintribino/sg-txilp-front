import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-etiquetas',
  templateUrl: './etiquetas.component.html',
  styleUrls: ['./etiquetas.component.styl']
})
export class EtiquetasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
