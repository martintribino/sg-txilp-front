import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-artistas',
  templateUrl: './artistas.component.html',
  styleUrls: ['./artistas.component.styl']
})
export class ArtistasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
