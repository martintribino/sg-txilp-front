import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-obras',
  templateUrl: './obras.component.html',
  styleUrls: ['./obras.component.styl']
})
export class ObrasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
