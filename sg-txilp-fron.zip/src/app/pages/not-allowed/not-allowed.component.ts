import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-allowed',
  templateUrl: './not-allowed.component.html',
  styleUrls: ['./not-allowed.component.styl']
})
export class NotAllowedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
