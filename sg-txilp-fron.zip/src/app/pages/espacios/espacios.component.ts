import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-espacios',
  templateUrl: './espacios.component.html',
  styleUrls: ['./espacios.component.styl']
})
export class EspaciosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
